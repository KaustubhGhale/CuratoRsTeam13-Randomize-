// src/App.js
import React from 'react'
import CollaborativeCodeEditor from './CollaborativeCodeEditor'
import './App.css'

function App() {
	return (
		<div className="App">
			<CollaborativeCodeEditor />
		</div>
	)
}

export default App
